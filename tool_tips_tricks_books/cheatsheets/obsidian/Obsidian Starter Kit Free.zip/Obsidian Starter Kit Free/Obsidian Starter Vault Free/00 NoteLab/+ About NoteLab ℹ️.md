
⬆️:: [[00 NoteLab|NoteLab]]

This is your default Inbox for your [[Fleeting Notes]].

A place to store your notes when you capture them.

**Helpful when;**
- You need to capture information as quickly as possible
- Make a lot of notes but don't have time to sort and organise them
- Capturing the note without friction is priority

If you like to keep your Vault Minimalistic then leave all your notes in the NoteLab 

---