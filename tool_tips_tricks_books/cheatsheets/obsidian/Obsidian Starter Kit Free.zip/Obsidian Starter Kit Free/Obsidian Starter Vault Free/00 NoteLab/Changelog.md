---
Source:
  - https://ko-fi.com/s/33678f10a7
YouTube: https://www.youtube.com/playlist?list=PLJJdpQJ7fSkYEMgPf_eLSdhSFyZACsBai
Last-Updated: 2024-09-04
Version: "1.1"
---

# 04/09/24
- Version 1.1 uploaded to KoFi
- [[Changelog]] added
- [[START HERE]] Added
- Added [[Obsidian Guide]]
- Added Feedback Form

# 08/07/24
- Version 1.0 released on YouTube and KoFi