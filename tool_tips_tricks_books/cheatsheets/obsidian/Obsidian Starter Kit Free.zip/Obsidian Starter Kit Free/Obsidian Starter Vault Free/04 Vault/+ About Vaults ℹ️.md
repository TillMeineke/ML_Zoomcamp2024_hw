
⬆️:: [[+ START HERE]]

---
 **Vaults are the place where you store all your captured information from external sources**

>[!tip] 
>This will be [[Literature Notes]] captured from consuming information

---

#### A few ideas of what to store in here could be:

1. Articles 📰️
2. Books 📖
3. Courses 🏫
4. Movies 🎥
5. Music 🎧
6. Papers 📜️ 
7. TV📺
8. Twitter 🐦️ 
9. Video 📽️
10. YouTube 🎥️

---


