---
Date-Created: 
tags:
  - "#My/Journal/Daily-Note"
Quarter: 
Month: 
Year: 
Location:
Overall-Mood:
aliases:
---
⬆️:: [[05 Journal]]

## Daily Journal
Learning:
Focus:

>[!example] Action Items
> - [ ] Task
> - [ ] Task   

### What was today's Highlight?
1.
2.
3.

### Daily Reflection

What caught my interest today?**
- 

**Anything you need to get off your mind?**


**What excited me today?**
* 

**What went right today?** 
* 

**What went wrong today?** 
* 
  
**What drained me of energy?**
* 
  
**What did I learn and work on?**
* 
  
**What are 3 things I'm grateful for?**
* 

**What ideas did I discover or have?**
* 

**How do I plan to have a better tomorrow?** 
* 