---
tags:
  - "#My/Journal/Monthly"
Date Added: 
Theme: 
To make awesome?: 
Gratitude: 
Wins for the Month: 
Achievements: 
Disappointments: 
Lows-Challenges:
---
⬆️:: [[05 Journal]]

## Monthly Review 
- Learning:
- Focus:

**Highlights:**
-

**Positives:**
-

**Negatives:**
-

**Gym Efforts:**
-

**Write down everything good that happened this month**

**Did I complete the goals I set for this month?**

**Am I happy with how the month went?**

**What did I do this month that I hadn't already planned to do?**

**What did I do for myself this month?**

**What needs improvement?**

**What am I going to start or continue doing next month?**

**Rate the month out of 10**

**What are my goals for next month?**

**What is the main focus next month?**


Back to [Previous Monthly Review]