---
Date-Created: 
tags:
  - "#My/Journal/Weekly"
Quarter: 
Month: 
Year:
Location:
Overall-Mood:
aliases:
---

⬆️:: [[05 Journal]]

## Weekly Review
- Learning:
- Focus:

**What was worth remembering about this week?**
* 

**What could I have done better this week?**
* 

**What can't I get off my mind, what is bugging me?**
* 

**What did I achieve this week?** 
* 

**What do I want to achieve next week?** 
* 
