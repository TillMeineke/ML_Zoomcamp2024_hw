---
Date-Created:
tags:
  - "#Fleeting Note"
  - "#🌱"
Type: "[[Fleeting]]"
Connected:
---
⬆️:: 

## Note